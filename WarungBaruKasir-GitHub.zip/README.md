# Warung Baru Kasir — starter project

Paket awal proyek Android (WebView), halaman kasir, Apps Script, dan workflow GitHub Actions untuk mencoba menghasilkan APK debug.

## Status yang perlu diketahui
Ini **belum APK siap operasional** dan belum diuji pada HP/printer. Ini kerangka awal untuk build pertama. Sebelum dipakai untuk uang dan stok sungguhan, sinkronisasi dua arah untuk enam perangkat, otorisasi akun lintas perangkat, konflik stok, serta cetak Bluetooth ESC/POS langsung perlu diselesaikan dan diuji. Versi awal ini menyimpan data lokal dan mengirim antrean perubahan ke Google Sheets; belum menarik seluruh data Sheet ke perangkat lain. Dialog cetak Android juga belum menjamin printer Bluetooth 58 mm akan terdeteksi.

## Fitur prototipe
- Tampilan kasir dan keranjang
- Produk dengan barcode, nama, satuan PCS/KG/L, modal, harga jual, stok
- Penyesuaian stok tambah/kurang/ubah
- Ringkasan omzet dan transaksi lokal
- Input barcode dari scanner Bluetooth mode keyboard/HID
- Antrean transaksi lokal saat offline
- Endpoint Google Apps Script untuk menerima catatan ke Google Sheets
- Workflow GitHub Actions untuk membuat APK debug

## Cara menyiapkan GitHub
1. Buat repository baru bernama `warung-baru-kasir`.
2. Ekstrak ZIP ini, lalu upload **isi folder** ke root repository (bukan ZIP sebagai satu file).
3. Buka tab Actions. Workflow `Build APK` akan berjalan setelah commit.
4. Jika build sukses, buka run terbaru > Artifacts > `warung-baru-debug-apk` untuk mengunduh APK.

## Google Sheets
1. Buat Google Sheet baru.
2. Extensions > Apps Script.
3. Ganti isi editor dengan `gas/Code.gs`, lalu Save.
4. Deploy > New deployment > Web app. Pilih Execute as: Me. Atur akses sesuai kebutuhan akun Google.
5. Salin URL Web App berakhiran `/exec`.
6. Masukkan URL itu ke konstanta `API_URL` di `app/src/main/assets/index.html`, lalu commit lagi.

Jangan masukkan password penting ke file publik GitHub. Akun awal dibuat lokal pada prototipe ini. Jangan bagikan Google Sheet atau URL Apps Script secara publik tanpa memahami pengaturan aksesnya.
