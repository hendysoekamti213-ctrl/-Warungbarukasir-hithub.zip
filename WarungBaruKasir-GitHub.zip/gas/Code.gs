const SHEETS = {
  products: ['Products', ['id','name','barcode','unit','stock','cost','price','updatedAt']],
  sales: ['Sales', ['id','at','cashier','total','paid','change','itemsJson']],
  stock: ['StockLog', ['id','at','productId','product','stock','by']],
  users: ['Users', ['id','name','role','updatedAt']]
};
function doGet(){return ContentService.createTextOutput(JSON.stringify({ok:true,service:'Warung Baru Kasir'})).setMimeType(ContentService.MimeType.JSON);}
function doPost(e){
  const lock=LockService.getScriptLock(); lock.waitLock(20000);
  try {
    const body=JSON.parse((e.postData && e.postData.contents)||'{}');
    if(body.action!=='sync') throw new Error('Aksi tidak dikenal');
    const ss=SpreadsheetApp.getActiveSpreadsheet(), results=[];
    Object.keys(SHEETS).forEach(k=>ensureSheet_(ss,k));
    (body.queue||[]).forEach(item=>{
      const d=item.data||{};
      if(item.type==='product'){
        upsert_(ss.getSheetByName('Products'), d.id, [d.id,d.name,d.barcode||'',d.unit,d.stock,d.cost,d.price,new Date().toISOString()]);
      } else if(item.type==='sale'){
        const exists=findRow_(ss.getSheetByName('Sales'), d.id);
        if(!exists) ss.getSheetByName('Sales').appendRow([d.id,d.at,d.cashier,d.total,d.paid,d.change,JSON.stringify(d.items||[])]);
      } else if(item.type==='stock'){
        ss.getSheetByName('StockLog').appendRow([Utilities.getUuid(),d.at||new Date().toISOString(),d.id,d.product,d.stock,d.by]);
      } else if(item.type==='user'){
        upsert_(ss.getSheetByName('Users'),d.id,[d.id,d.name,d.role,new Date().toISOString()]);
      }
      results.push({ok:true,type:item.type});
    });
    return json_({ok:true,processed:results.length,serverTime:new Date().toISOString()});
  } catch(err){return json_({ok:false,error:String(err)});}
  finally{lock.releaseLock();}
}
function ensureSheet_(ss,key){
  const spec=SHEETS[key]; let sh=ss.getSheetByName(spec[0]);
  if(!sh){sh=ss.insertSheet(spec[0]);sh.appendRow(spec[1]);}
}
function findRow_(sh,id){
  if(sh.getLastRow()<2)return 0;
  const vals=sh.getRange(2,1,sh.getLastRow()-1,1).getValues();
  for(let i=0;i<vals.length;i++)if(String(vals[i][0])===String(id))return i+2;
  return 0;
}
function upsert_(sh,id,row){const r=findRow_(sh,id);if(r)sh.getRange(r,1,1,row.length).setValues([row]);else sh.appendRow(row);}
function json_(o){return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);}
